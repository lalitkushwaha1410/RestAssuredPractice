package com.dpm.extentreport;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Readprop  {

		
		public void readproperty() throws IOException

		{
			
			Properties prop = new Properties();
		
		try {
			FileInputStream ip = new FileInputStream("C:/Users/lka2/eclipse-workspace2019/WebservicesBDDFramework/src/main/java/Config.properties");
			
			prop.load(ip);
			
			String BaseURL =prop.getProperty("Baseurl");
			System.out.println("baseurl : "+ prop.getProperty("Baseurl"));
			
			String SessionID =prop.getProperty("sessionid");
			System.out.println("SessionID :"+ prop.getProperty("sessionid"));
				
			String CSRFToken =prop.getProperty("csrftoken");
			System.out.println("CSRF Token : "+ prop.getProperty("csrftoken"));
				
		} 
		
		catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	}
}
