package com.dpm.apitest;
import static org.testng.Assert.assertEquals;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.response.ResponseBodyExtractionOptions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.hamcrest.Matchers;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.Reporter;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import groovyjarjarantlr.collections.List;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.ValidatableResponse;


public class CSRFToken {	
	
	public String sessionid;
	public String csrftoken;
	Properties prop = new Properties();
	
		
	@BeforeTest
	public void HandleSSLCeritificate() throws IOException 
	{
		
		try 
		{
	        RestAssured.port = 8080;
	        RestAssured.useRelaxedHTTPSValidation();
	        RestAssured.config().getSSLConfig().with().keyStore("classpath:keystore.p12", "password");
	    } 
		
		catch (Exception ex) 
		{
	        System.out.println("Error while loading keystore >>>>>>>>>");
	        ex.printStackTrace();
	    }
		
	
		try {
			
			FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"/Config.properties");
			
			
			prop.load(ip);

			String propSessionID =prop.getProperty("sessionid");
	//		System.out.println("SessionID :"+ propSessionID);
			sessionid=propSessionID;
				
		//	String CSRFToken =prop.getProperty("csrftoken");
		//	System.out.println("CSRF Token : "+ CSRFToken);
				
		} 
		
		catch (FileNotFoundException e) {
			
			e.printStackTrace();
				
		}
		
	}
	
	
	@Test(priority=1)
	public void Generate_CSRF_Token() throws IOException
	{		
		
	
		
	//	RestAssured.baseURI ="https://vdevpril56plp.dsone.3ds.com:443/3DSpace/resources/v1/application/CSRF"; 
		
		RestAssured.baseURI=prop.getProperty("CSRFBaseurl");
		
		String response1 = RestAssured.given().cookie("JSESSIONID","\""+sessionid+"\"").auth().basic("devleader1", "Passport1").when().get().then().extract().asString();
		ValidatableResponse res = RestAssured.given().cookie("JSESSIONID","\""+sessionid+"\"").auth().basic("devleader1", "Passport1").when().get().then();
		res.statusCode(200);
		res.contentType(ContentType.JSON);
		
		System.out.println("Response output is =  : " + response1);
		
	    JsonPath js = new JsonPath(response1);
		String csrfid = js.get("csrf.value");
		Object statuscode  = js.get("statusCode");
		csrftoken=csrfid;
		prop.setProperty("csrftoken", "csrfid");
		
		res.body("statusCode", Matchers.comparesEqualTo(200));
		Reporter.log("status code validated successfully :" +statuscode, true);
		Reporter.log("CSRF Token Generated :" + csrftoken , true);

	}
	
	
	@Test(priority=2)
	public void Get_ProjectList() throws ParseException
	{
		
		
	  //RestAssured.baseURI ="https://vdevpril56plp.dsone.3ds.com/3DSpace/resources/v1/modeler/projects";
		RestAssured.baseURI=prop.getProperty("ProjectListBaseurl");
		String username=prop.getProperty("user");
		String userpassword=prop.getProperty("password");
		String securitycontext=prop.getProperty("scontext");
		
		String response2 = RestAssured.given().queryParam("include","none,subscriptions").queryParam("fields","none.name").and().header("SecurityContext","ctx::VPLMProjectLeader.MyCompany.Dev").header("ENO_CSRF_TOKEN","\""+csrftoken+"\"").and().header("Content-Type","application/json")
				.cookie("JSESSIONID","\""+sessionid+"\"").auth().basic("\""+username+"\"" , "\""+userpassword+"\"")
				.when().get().then().statusCode(200).extract().asString();
		
		ValidatableResponse res2 = RestAssured.given().queryParam("include","none,subscriptions").queryParam("fields","none.name").and().header("SecurityContext","ctx::VPLMProjectLeader.MyCompany.Dev").header("ENO_CSRF_TOKEN","\""+csrftoken+"\"").and().header("Content-Type","application/json")
		.cookie("JSESSIONID","\""+sessionid+"\"").auth().basic("\""+username+"\"" , "\""+userpassword+"\"")
		.when().get().then();
		
	 	System.out.println("Project List =  : " + response2);
	 	
	 	JsonPath js2 = new JsonPath(response2);
	 	
	 	
	 	
		/*
		 * res2.body("statusCode", Matchers.comparesEqualTo(200));
		 * Reporter.log("status code validation done successfully" , true);
		 * 
		 * 
		 * res2.body("data[0].dataelements.title", Matchers.comparesEqualTo("Test1"));
		 * res2.body("data[1].dataelements.title",
		 * Matchers.comparesEqualTo("Project1"));
		 * Reporter.log("Project names validation done successfully" , true);
		 * 
		 */
	    
	  }


	
}
		
